import os
import re
import json
import requests
import fitz  
import streamlit as st
import spacy
from rank_bm25 import BM25Okapi
from nltk.stem import PorterStemmer
from fuzzywuzzy import process

# Load NLP model
nlp = spacy.load("en_core_web_sm")

# Global Variables
documents = {}
bm25_index = {}
chat_history = []
disease_files = {}
stemmer = PorterStemmer()

# Function to tokenize text using spaCy
def tokenize_text(text):
    doc = nlp(text.lower())
    return [token.lemma_ for token in doc if not token.is_punct and not token.is_space]

# Load PDFs and Extract Text
def load_pdfs():
    global documents, bm25_index, disease_files
    pdf_dir = os.path.join(os.getcwd(), "intents")  

    if not os.path.exists(pdf_dir):
        print("Error: 'intents' directory not found.")
        return

    files = [f for f in os.listdir(pdf_dir) if f.endswith(".pdf")]
    if not files:
        print("Error: No PDF files found in 'intents' directory.")
        return

    for file in files:
        file_path = os.path.join(pdf_dir, file)
        try:
            doc = fitz.open(file_path)
            text = "\n".join([page.get_text("text") for page in doc])

            if text.strip():
                disease_name = file.replace(".pdf", "").lower()
                documents[disease_name] = text
                disease_files[disease_name] = file_path

                tokenized_text = tokenize_text(text)
                bm25_index[disease_name] = BM25Okapi([tokenized_text])

        except Exception as e:
            print(f"Error loading {file}: {e}")

load_pdfs()

# Hugging Face API Key
HUGGINGFACE_API_KEY = "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"
HF_MODEL = "HuggingFaceH4/zephyr-7b-beta"

# Function to Query Hugging Face API
def query_huggingface_api(prompt, query_length):
    max_tokens = min(150, max(50, query_length * 5))
    url = f"https://api-inference.huggingface.co/models/{HF_MODEL}"
    headers = {"Authorization": f"Bearer {HUGGINGFACE_API_KEY}"}
    payload = {"inputs": prompt, "parameters": {"max_new_tokens": max_tokens}}

    response = requests.post(url, headers=headers, json=payload)
    if response.status_code == 200:
        try:
            return response.json()[0].get("generated_text", "No relevant information found.")
        except (KeyError, IndexError):
            return "Error: Unexpected response format."
    return f"Error: {response.json().get('error', 'Unknown error')}"

# Agents
class Agent:
    def handle(self, user_input):
        raise NotImplementedError()

class GreetingAgent(Agent):
    def handle(self, user_input):
        return "Hello! 😊 How can I assist you with rice diseases today?"

class DiseaseAgent(Agent):
    def get_closest_disease(self, user_input):
        disease_names = list(disease_files.keys())
        user_input_stemmed = " ".join(stemmer.stem(word) for word in user_input.lower().split())

        stemmed_diseases = {disease: " ".join(stemmer.stem(word) for word in disease.split()) for disease in disease_names}

        match, score = process.extractOne(user_input_stemmed, list(stemmed_diseases.values()))

        for original, stemmed in stemmed_diseases.items():
            if stemmed == match:
                return original if score > 70 else None  

        return None

    def get_disease_info(self, disease_name, query):
        if disease_name.lower() not in documents:
            return None

        text = documents[disease_name.lower()]
        sections = {
            "Definition": ["define", "definition", "about", "explain"],
            "Cause": ["cause", "caused by", "responsible for"],
            "Symptoms": ["symptoms", "signs", "how it appears"],
            "Treatment": ["treatment", "cure", "solution", "management"],
            "Prevention": ["prevention", "avoid", "control", "stop"]
        }

        query_stemmed = [stemmer.stem(word) for word in re.findall(r'\w+', query.lower())]
        requested_sections = [sec for sec, keywords in sections.items() if any(stemmer.stem(k) in query_stemmed for k in keywords)]
        if not requested_sections:
            requested_sections = ["Definition", "Symptoms", "Cause", "Treatment"]

        extracted_info = {}
        text_lines = text.split("\n")

        for section in requested_sections:
            extracted_info[section] = None
            for i, line in enumerate(text_lines):
                if any(keyword.lower() in line.lower() for keyword in sections[section]):
                    extracted_info[section] = text_lines[i].strip()
                    break

        return extracted_info if any(extracted_info.values()) else None

    def handle(self, user_input):
        matched_disease = self.get_closest_disease(user_input)
        if not matched_disease:
            return "I specialize in rice diseases. Please specify a disease name."

        disease_info = self.get_disease_info(matched_disease, user_input)
        if not disease_info:
            return f"No detailed information found for {matched_disease}."

        response = f"🌿 **{matched_disease.capitalize()} Disease Information**\n\n"
        for section, content in disease_info.items():
            if content:
                response += f"🔹 **{section}:**\n{content}\n\n"

        return response

class FallbackAgent(Agent):
    def handle(self, user_input):
        return "I'm not sure about that. Try asking about a specific rice disease."

# Chatbot Controller
class Chatbot:
    def __init__(self):
        self.agents = {
            "greeting": GreetingAgent(),
            "disease": DiseaseAgent(),
            "fallback": FallbackAgent()
        }
        self.chat_history = []

    def classify_intent(self, user_input):
        greetings = ["hi", "hello", "hey", "good morning", "good evening", "good afternoon"]
        if user_input.lower() in greetings:
            return "greeting"
        elif any(word in user_input.lower() for word in disease_files.keys()):
            return "disease"
        return "fallback"

    def respond(self, user_input):
        intent = self.classify_intent(user_input)
        response = self.agents[intent].handle(user_input)

        self.chat_history.append({"user": user_input, "bot": response})
        if len(self.chat_history) > 8:
            self.chat_history.pop(0)

        return response

chatbot = Chatbot()

# Streamlit UI
def main():
    st.title("Rice Disease Chatbot 🌱")
    
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    user_input = st.text_input("You:", "")

    if st.button("Ask"):
        if user_input.strip():
            response = chatbot.respond(user_input)
            st.session_state.chat_history.append({"user": user_input, "bot": response})

            for chat in st.session_state.chat_history[-8:]:
                st.write(f"**You:** {chat['user']}")
                st.write(f"**Bot:** {chat['bot']}")
        else:
            st.warning("Please enter a question.")

if __name__ == "__main__":
    main()
