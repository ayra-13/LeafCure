# import requests

# API_KEY = "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"
# MODEL = "tiiuae/falcon-7b-instruct"  # Try replacing with another model

# url = f"https://api-inference.huggingface.co/models/{MODEL}"
# headers = {"Authorization": f"Bearer {API_KEY}"}
# payload = {"inputs": "What is rice blast disease?"}

# response = requests.post(url, headers=headers, json=payload)
# print(response.json())  # Check for any errors



# import os

# intents_folder = "intents"
# print("Folder Exists:", os.path.exists(intents_folder))
# print("Files in intents folder:", os.listdir(intents_folder))




# from transformers import pipeline

# def get_rice_disease_info(disease_name):
#     """
#     Generates a brief explanation of the specified rice disease using Hugging Face transformers.
#     """
#     # Load the Hugging Face text generation model
#     generator = pipeline("text-generation", model="EleutherAI/gpt-neo-2.7B")  # You can change the model

#     # Define the prompt
#     prompt = f"Briefly explain '{disease_name}' disease in rice."

#     # Generate response
#     response = generator(prompt, max_length=50, temperature=0.7)

#     # Extract and clean the result
#     clean_result = response[0]["generated_text"].strip()
#     return clean_result

# if __name__ == "__main__":
#     # Ask for disease name
#     disease_name = input("Enter the rice disease name: ")
    
#     # Get disease information
#     result = get_rice_disease_info(disease_name)

#     # Print the result
#     print("\nGenerated Response:")
#     print(result)



import os
import fitz  # PyMuPDF

folder_path = "C:\\Users\\World\\Desktop\\chatbot_project\\intents"
pdf_files = [f for f in os.listdir(folder_path) if f.endswith(".pdf")]

for pdf in pdf_files:
    doc = fitz.open(os.path.join(folder_path, pdf))
    text = "\n".join([page.get_text() for page in doc])
    print(f"Extracted text from {pdf}:\n", text[:500])  # Print first 500 characters

