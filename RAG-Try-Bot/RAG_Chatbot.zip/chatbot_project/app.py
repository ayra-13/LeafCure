import streamlit as st
from chatbot import Chatbot

# Initialize chatbot instance
chatbot = Chatbot()

# Streamlit UI Configuration
st.set_page_config(page_title="RAG Chatbot", layout="centered")

st.title("🌾 Rice Disease Chatbot 🤖")
st.write("Ask me anything about rice diseases!")

# Initialize chat history
if "messages" not in st.session_state:
    st.session_state["messages"] = []

# Display chat history
for message in st.session_state["messages"]:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# User input handling
user_input = st.chat_input("Type your message...")
if user_input:
    # Store and display user message
    st.session_state["messages"].append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)

    # Generate bot response with error handling
    try:
        bot_response = chatbot.respond(user_input)
        if not bot_response.strip():  # Handle empty responses
            bot_response = "🤖 I'm not sure about that. Try asking about a specific rice disease."
    except Exception as e:
        bot_response = f"⚠️ Oops! Something went wrong: {str(e)}"

    # Store and display bot response
    st.session_state["messages"].append({"role": "assistant", "content": bot_response})
    with st.chat_message("assistant"):
        st.markdown(bot_response)
