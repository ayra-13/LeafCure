import os
import re
import json
import requests
import fitz  
import streamlit as st
import spacy
from rank_bm25 import BM25Okapi
from nltk.stem import PorterStemmer
from fuzzywuzzy import process

# Load SpaCy NLP model
nlp = spacy.load("en_core_web_sm")

# Global Variables
documents = {}
bm25_index = {}
chat_history = []
disease_files = {}
stemmer = PorterStemmer()

# Function to tokenize text using spaCy
def tokenize_text(text):
    doc = nlp(text.lower())
    return [token.lemma_ for token in doc if not token.is_punct and not token.is_space]

# Function to Load PDFs and Extract Text
def load_pdfs():
    global documents, bm25_index, disease_files
    pdf_dir = os.path.join(os.getcwd(), "intents")  

    if not os.path.exists(pdf_dir):
        print("Error: 'intents' directory not found.")
        return

    files = [f for f in os.listdir(pdf_dir) if f.endswith(".pdf")]
    if not files:
        print("Error: No PDF files found in 'intents' directory.")
        return

    for file in files:
        file_path = os.path.join(pdf_dir, file)
        try:
            doc = fitz.open(file_path)
            text = "\n".join([page.get_text("text") for page in doc])

            if text.strip():
                disease_name = file.replace(".pdf", "").lower()
                documents[disease_name] = text
                disease_files[disease_name] = file_path

                tokenized_text = tokenize_text(text)
                bm25_index[disease_name] = BM25Okapi([tokenized_text])

        except Exception as e:
            print(f"Error loading {file}: {e}")

load_pdfs()






# Hugging Face API Key (Replace with your own)
HUGGINGFACE_API_KEY = "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"
HF_MODEL = "HuggingFaceH4/zephyr-7b-beta"


    # If it's missing, try an alternative model, such as:

    # "HuggingFaceH4/zephyr-7b-beta"
    # "tiiuae/falcon-7b-instruct"
    # "meta-llama/Llama-2-7b-chat-hf"
    # "mistralai/Mistral-7B-Instruct"



# Function to Query Hugging Face API
def query_huggingface_api(prompt, query_length):
    max_tokens = min(150, max(50, query_length * 5))
    url = f"https://api-inference.huggingface.co/models/{HF_MODEL}"
    headers = {"Authorization": f"Bearer {HUGGINGFACE_API_KEY}"}
    payload = {"inputs": prompt, "parameters": {"max_new_tokens": max_tokens}}

    response = requests.post(url, headers=headers, json=payload)
    if response.status_code == 200:
        try:
            return response.json()[0].get("generated_text", "No relevant information found.")
        except (KeyError, IndexError):
            return "Error: Unexpected response format."
    return f"Error: {response.json().get('error', 'Unknown error')}"

# Function to get the closest disease name
def get_closest_disease(user_input):
    disease_names = list(disease_files.keys())
    match, score = process.extractOne(user_input.lower(), disease_names)
    return match if score > 70 else None  

# Function to get disease information
def get_disease_info(disease_name, query):
    if disease_name.lower() not in documents:
        return None

    text = documents[disease_name.lower()]
    sections = {
        "Definition": ["define", "definition", "about", "explain"],
        "Cause": ["cause", "caused by", "responsible for"],
        "Symptoms": ["symptoms", "signs", "how it appears"],
        "Treatment": ["treatment", "cure", "solution", "management"],
        "Prevention": ["prevention", "avoid", "control", "stop"]
    }

    query_stemmed = [stemmer.stem(word) for word in re.findall(r'\w+', query.lower())]
    requested_sections = [sec for sec, keywords in sections.items() if any(stemmer.stem(k) in query_stemmed for k in keywords)]
    if not requested_sections:
        requested_sections = ["Definition", "Symptoms", "Cause", "Treatment"]

    extracted_info = {}
    text_lines = text.split("\n")

    for section in requested_sections:
        extracted_info[section] = None
        for i, line in enumerate(text_lines):
            if any(keyword.lower() in line.lower() for keyword in sections[section]):
                extracted_info[section] = text_lines[i].strip()
                break

    return extracted_info if any(extracted_info.values()) else None

# Chatbot Response Function
def rag_chatbot(user_input):
    global chat_history

    greetings = ["hi", "hello", "hey", "good morning", "good evening", "good afternoon"]
    if user_input.lower() in greetings:
        return "Hello! 😊 How can I assist you with rice diseases today?"

    if not bm25_index or not documents:
        return "Error: No disease documents found."

    matched_disease = get_closest_disease(user_input)
    if not matched_disease:
        return "I specialize in rice diseases. Please specify a disease name."

    disease_info = get_disease_info(matched_disease, user_input)
    if not disease_info:
        return f"No detailed information found for {matched_disease}."

    response = f"🌿 **{matched_disease.capitalize()} Disease Information**\n\n"
    for section, content in disease_info.items():
        if content:
            response += f"🔹 **{section}:**\n{content}\n\n"

    chat_history.append({"user": user_input, "bot": response})
    if len(chat_history) > 5:
        chat_history.pop(0)

    return response

# Streamlit UI
def main():
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    user_input = st.text_input("You:", "")

    if st.button("Ask"):
        if user_input.strip():
            response = rag_chatbot(user_input)
            st.session_state.chat_history.append({"user": user_input, "bot": response})

            for chat in st.session_state.chat_history[-5:]:
                st.text_area("You:", value=chat["user"], height=50, key=f"user_{chat['user']}")
                st.text_area("Bot:", value=chat["bot"], height=80, key=f"bot_{chat['bot']}")
        else:
            st.warning("Please enter a question.")

if __name__ == "__main__":
    main()