import os
import torch
import numpy as np
import logging
import matplotlib.pyplot as plt
from PIL import Image
from torchvision import models, transforms
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from .models import UploadedImage
from .serializers import ImageUploadSerializer
from torch.nn.functional import interpolate
from django.conf import settings
import base64
from django.core.files.base import ContentFile
from django.urls import reverse
import time

# Configure logging
logging.basicConfig(filename="predictions.log", level=logging.INFO)

# Load the trained model
def load_model(model_path, num_classes):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = models.efficientnet_b0(pretrained=False)
    num_features = model.classifier[1].in_features
    model.classifier[1] = torch.nn.Linear(num_features, num_classes)
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.to(device)
    model.eval()
    return model

# Image preprocessing
def remove_alpha_channel(img):
    if img.mode == 'RGBA':
        img = img.convert('RGB')
    return img

transform = transforms.Compose([
    transforms.Lambda(remove_alpha_channel),
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

# Grad-CAM Implementation
def generate_gradcam(model, image_tensor, target_layer, class_index):
    gradients = []
    activations = []

    def forward_hook(module, input, output):
        activations.append(output)

    def backward_hook(module, grad_input, grad_output):
        gradients.append(grad_output[0])

    handle_forward = target_layer.register_forward_hook(forward_hook)
    handle_backward = target_layer.register_backward_hook(backward_hook)

    outputs = model(image_tensor)
    model.zero_grad()

    class_score = outputs[0, class_index]
    class_score.backward()

    gradients = gradients[0].cpu().data.numpy()[0]
    activations = activations[0].cpu().data.numpy()[0]
    weights = np.mean(gradients, axis=(1, 2))
    gradcam = np.sum(weights[:, np.newaxis, np.newaxis] * activations, axis=0)
    gradcam = np.maximum(gradcam, 0)
    gradcam = gradcam / gradcam.max()

    handle_forward.remove()
    handle_backward.remove()

    return gradcam

# Overlay Grad-CAM on the image
def overlay_gradcam_on_image(image, gradcam):
    gradcam_resized = interpolate(torch.tensor(gradcam).unsqueeze(0).unsqueeze(0), size=image.size[::-1], mode='bilinear', align_corners=False).squeeze().numpy()
    heatmap = plt.cm.jet(gradcam_resized)[:, :, :3]
    overlay = (0.4 * heatmap + 0.6 * np.array(image) / 255.0).clip(0, 1)
    return (overlay * 255).astype(np.uint8)

# Disease mitigation steps
# Disease mitigation steps
disease_mitigation = {
    "Bacterial Leaf Blight":
        "1. Use resistant varieties like IR64, IR72, or IRBB60. \n"
        "2. Avoid over-fertilization, especially nitrogen, which promotes disease. \n"
        "3. Ensure proper water drainage to prevent waterlogging. \n"
        "4. Practice crop rotation with non-host crops like legumes. \n"
        "5. Remove and burn infected plant debris to reduce bacterial spread. \n"
        "6. Apply seed treatments with hot water or antibiotics to eliminate bacteria. \n"
        "7. Use balanced fertilizers to maintain plant health and resistance.",
    "Brown Spot":
        "1. Apply balanced fertilizers with adequate potassium and phosphorus. \n"
        "2. Remove and burn infected plant debris to reduce spore spread. \n"
        "3. Ensure good air circulation by maintaining proper plant spacing. \n"
        "4. Rotate crops with non-cereal crops like legumes to break the disease cycle. \n"
        "5. Use certified, disease-free seeds for planting. \n"
        "6. Avoid water stress by maintaining consistent irrigation. \n"
        "7. Apply foliar sprays to protect healthy leaves from infection.",
    "Leaf Blast":
        "1. Use resistant varieties like IR64, Swarna, or IRBL9. \n"
        "2. Apply fungicides during the early stages of infection. \n"
        "3. Avoid excessive nitrogen fertilizers, which promote disease. \n"
        "4. Maintain good field sanitation by removing infected leaves. \n"
        "5. Practice crop rotation with non-host crops like legumes. \n"
        "6. Ensure proper irrigation to avoid water stress. \n"
        "7. Use seed treatments to eliminate fungal spores.",
    "Leaf Scald":
        "1. Ensure good field sanitation by removing infected plant material. \n"
        "2. Control humidity by avoiding over-irrigation and improving drainage. \n"
        "3. Use fungicides during the early stages of infection. \n"
        "4. Practice crop rotation with non-host crops like legumes. \n"
        "5. Use resistant varieties like IR36 or IR50. \n"
        "6. Apply balanced fertilizers to maintain plant health. \n"
        "7. Monitor fields regularly for early signs of infection.",
    "Narrow Brown Leaf Spot":
        "1. Use certified, disease-free seeds for planting. \n"
        "2. Maintain balanced soil nutrients, especially potassium. \n"
        "3. Apply fungicides during the early stages of infection. \n"
        "4. Remove and destroy infected plant material. \n"
        "5. Practice crop rotation with non-host crops like legumes. \n"
        "6. Ensure proper irrigation to avoid water stress. \n"
        "7. Use resistant varieties like IR64 or IR72.",
    "Rice Hispa":
        "1. Hand-pick and destroy larvae to reduce infestation. \n"
        "2. Apply neem oil or neem-based pesticides. \n"
        "3. Use resistant varieties like IR36 or IR50. \n"
        "4. Regularly inspect plants for signs of infestation. \n"
        "5. Maintain proper field sanitation by removing weeds and debris. \n"
        "6. Use light traps to monitor and control adult populations. \n"
        "7. Apply balanced fertilizers to avoid excessive nitrogen, which attracts pests.",
    "Sheath Blight":
        "1. Plant resistant varieties like Jasmine 85 or IR72. \n"
        "2. Use proper spacing to reduce humidity and disease spread. \n"
        "3. Apply fungicides during the early stages of infection. \n"
        "4. Remove infected plants promptly to prevent spread. \n"
        "5. Practice crop rotation with non-host crops like legumes. \n"
        "6. Ensure proper irrigation to avoid waterlogging. \n"
        "7. Use balanced fertilizers to maintain plant health.",
    "Tungro":
        "1. Control leafhoppers using insecticides or natural predators. \n"
        "2. Use resistant varieties like IR36 or IR50. \n"
        "3. Practice field sanitation by removing infected plants. \n"
        "4. Rotate crops with non-host crops to reduce disease persistence. \n"
        "5. Apply balanced fertilizers to maintain plant health. \n"
        "6. Use barrier crops to deter leafhoppers. \n"
        "7. Monitor fields regularly for early signs of infection."
}

# Chemicals to use
chemicals_to_use = {
    "Bacterial Leaf Blight": [
        "Streptomycin sulfate (Agrimycin)",
        "Copper-based fungicides (e.g., Kocide 3000)",
        "Kasugamycin"
    ],
    "Brown Spot": [
        "Mancozeb (Dithane M-45)",
        "Azoxystrobin (Amistar)",
        "Carbendazim (Bavistin)"
    ],
    "Leaf Blast": [
        "Tricyclazole (Beam)",
        "Isoprothiolane (Fuji-One)",
        "Pyroquilon (Fongorene)"
    ],
    "Leaf Scald": [
        "Propiconazole (Tilt)",
        "Carbendazim (Bavistin)",
        "Tebuconazole (Folicur)"
    ],
    "Narrow Brown Leaf Spot": [
        "Mancozeb (Dithane M-45)",
        "Tebuconazole (Folicur)",
        "Azoxystrobin (Amistar)"
    ],
    "Rice Hispa": [
        "Chlorpyriphos (Dursban)",
        "Cypermethrin (Ammo)",
        "Imidacloprid (Confidor)"
    ],
    "Sheath Blight": [
        "Validamycin (Sheathmar)",
        "Hexaconazole (Contaf)",
        "Propiconazole (Tilt)"
    ],
    "Tungro": [
        "Imidacloprid (Confidor)",
        "Thiamethoxam (Actara)",
        "Carbofuran (Furadan)"
    ]
}

# Tips for healthy leaves
healthy_leaf_tips = (
    "1. Maintain proper irrigation to avoid water stress. \n"
    "2. Use balanced fertilizers with nitrogen, phosphorus, and potassium. \n"
    "3. Practice good crop rotation with legumes or other non-host crops. \n"
    "4. Monitor for pests regularly and take preventive measures. \n"
    "5. Ensure proper spacing between plants to improve airflow. \n"
    "6. Use certified, disease-free seeds for planting. \n"
    "7. Apply organic mulches to retain soil moisture and suppress weeds. \n"

)
class ImageUploadView(APIView):
    def post(self, request, *args, **kwargs):
        logger = logging.getLogger(__name__)
        logger.info(f"Incoming request data: {request.data}")

        image_data = request.data.get('image')
        if not image_data:
            logger.error("No image provided in the request")
            return Response({"error": "No image provided"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            if ';base64,' in image_data:
                format, imgstr = image_data.split(';base64,')
                ext = format.split('/')[-1]
            else:
                imgstr = image_data
                ext = 'jpg'

            image_file = ContentFile(base64.b64decode(imgstr), name=f'temp.{ext}')
        except Exception as e:
            logger.error(f"Invalid image format: {e}")
            return Response({"error": "Invalid image format"}, status=status.HTTP_400_BAD_REQUEST)

        uploaded_image = UploadedImage(image=image_file)
        uploaded_image.save()

        image = Image.open(uploaded_image.image)
        transformed_image = transform(image).unsqueeze(0)

        model_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static',
                                  'model_extendedclass_fold_5_val_acc_0.9968.pth')

        num_classes = 9
        class_names = [
            "Bacterial Leaf Blight", "Brown Spot", "Healthy Rice Leaf", "Leaf Blast", "Leaf Scald",
            "Narrow Brown Leaf Spot", "Rice Hispa", "Sheath Blight", "Tungro"
        ]

        model = load_model(model_path, num_classes)
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        transformed_image = transformed_image.to(device)

        with torch.no_grad():
            outputs = model(transformed_image)
            _, predicted = torch.max(outputs, 1)

        predicted_class = class_names[predicted.item()]
        target_layer = model.features[-1]
        gradcam = generate_gradcam(model, transformed_image, target_layer, predicted.item())
        gradcam_overlay = overlay_gradcam_on_image(image, gradcam)

        output_path = os.path.join(settings.MEDIA_ROOT, 'gradcam_overlay.png')

        # Delete the previous image if it exists
        if os.path.exists(output_path):
            os.remove(output_path)

        # Save the new image
        Image.fromarray(gradcam_overlay).save(output_path)
        gradcam_image_url = request.build_absolute_uri(settings.MEDIA_URL + 'gradcam_overlay.png') + f"?t={time.time()}"

        # Prepare response data
        response_data = {
            "class": predicted_class,
            "gradcam_image_url": gradcam_image_url,
        }

        if predicted_class == "Healthy Rice Leaf":
            response_data["tips"] = healthy_leaf_tips
        else:
            response_data["mitigation_steps"] = disease_mitigation.get(
                predicted_class, "No specific mitigation steps available."
            )
            # Add chemicals to use for the predicted disease
            response_data["chemicals_to_use"] = chemicals_to_use.get(
                predicted_class, ["No specific chemicals recommended."]
            )

        logger.info(f"Image: {uploaded_image.image.name}, Prediction: {predicted_class}, Grad-CAM Overlay Saved")
        return Response(response_data, status=status.HTTP_200_OK)