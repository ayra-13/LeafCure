import os
import django
import json
import requests

# Set up Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'image_classification_api.settings')
django.setup()


def test_chat():
    # Create a new chat session
    response = requests.post(
        'http://localhost:8000/rag/chat/',
        json={'message': 'Hello, how are you?'}
    )

    if response.status_code == 200:
        data = response.json()
        print(f"Bot: {data['response']}")
        session_id = data['session_id']

        # Continue the chat
        while True:
            user_input = input("You: ")
            if user_input.lower() in ['exit', 'quit', 'q']:
                break

            response = requests.post(
                f'http://localhost:8000/rag/chat/{session_id}/',
                json={'message': user_input}
            )

            if response.status_code == 200:
                data = response.json()
                print(f"Bot: {data['response']}")
            else:
                print(f"Error: {response.text}")
    else:
        print(f"Error: {response.text}")


if __name__ == "__main__":
    test_chat()