from django.urls import path
from . import views

urlpatterns = [
    path('chat/', views.chat_view, name='chat'),
    path('chat/<str:session_id>/', views.chat_session_view, name='chat_session'),
    path('sessions/', views.chat_sessions_view, name='chat_sessions'),
]