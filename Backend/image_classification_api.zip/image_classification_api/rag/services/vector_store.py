from langchain_community.vectorstores import Chroma


class VectorStoreService:
    def __init__(self, embeddings_service):
        self.embeddings = embeddings_service.get_embeddings()
        self.persist_directory = "./chroma_db"

    def load(self):
        """Load existing Chroma vector store"""
        try:
            return Chroma(
                persist_directory=self.persist_directory,
                embedding_function=self.embeddings
            )
        except Exception as e:
            print(f"Error loading vector store: {str(e)}")
            return None

    def similarity_search_with_score(self, query, k=3):
        """Search vector store for similar documents with scores"""
        vector_store = self.load()
        if vector_store:
            return vector_store.similarity_search_with_score(query, k=k)
        return []