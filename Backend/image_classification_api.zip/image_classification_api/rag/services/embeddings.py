import os
from langchain_cohere import CohereEmbeddings
from dotenv import load_dotenv
load_dotenv()

class EmbeddingsService:
    def __init__(self):
        self.embeddings = CohereEmbeddings(
            model="embed-english-light-v3.0",
            cohere_api_key=os.getenv("COHERE_API_KEY")
        )

    def get_embeddings(self):
        return self.embeddings