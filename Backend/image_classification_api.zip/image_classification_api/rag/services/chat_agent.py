import os
from django.utils import timezone
from langchain_core.runnables import RunnablePassthrough
from langchain_core.prompts import ChatPromptTemplate
from langchain_groq import ChatGroq
from langchain_core.output_parsers import StrOutputParser
from ..models import ChatSession, ChatMessage
from dotenv import load_dotenv
load_dotenv()

class ChatAgent:
    def __init__(self, vector_store_service, session_id):
        self.vector_store_service = vector_store_service
        self.llm = ChatGroq(
            model_name="llama-3.1-8b-instant",
            api_key=os.getenv("GROQ_API_KEY")
        )
        self.session_id = session_id

        # Get or create chat session
        self.chat_session, _ = ChatSession.objects.get_or_create(
            session_id=session_id
        )

    def retrieve_context(self, query):
        """Retrieve relevant text chunks from ChromaDB with score filtering."""
        docs_with_scores = self.vector_store_service.similarity_search_with_score(query, k=3)

        # Filter out irrelevant results (only keep scores ≥ 0.7)
        filtered_docs = [doc for doc, score in docs_with_scores if score >= 0.7]

        if not filtered_docs:
            return "I could not find relevant information in the database."

        # Combine document text
        context = "\n".join([doc.page_content for doc in filtered_docs])
        return context

    def get_last_5_chats(self):
        """Fetch last 5 user-bot exchanges for maintaining context."""
        messages = ChatMessage.objects.filter(
            session=self.chat_session
        ).order_by('-timestamp')[:10]  # Get last 10 messages (5 exchanges)

        # Format chat history as a readable string
        chat_history = "\n".join([
            f"{'User' if msg.role == 'user' else 'Bot'}: {msg.content}"
            for msg in reversed(messages)  # Reverse to maintain chronological order
        ])

        return chat_history

    def chat(self, user_input):
        """Handles user input, retrieves relevant context, and generates a response."""
        context = self.retrieve_context(user_input)

        # If retrieval fails, return an explicit "no information" response
        if not context.strip() or "I could not find relevant information" in context:
            response = "I do not have information on this topic."
            self._store_conversation(user_input, response)
            return response

        chat_history = self.get_last_5_chats()

        prompt = ChatPromptTemplate.from_template(
            """You are an intelligent AI assistant. **Follow these rules**:

            1️⃣ If the user input is **greetings or casual chat**, keep responses **brief and natural**.
            2️⃣ If the query is **technical or knowledge-based**, provide an **accurate response using retrieved context**.
            3️⃣ **Do NOT generate answers outside of retrieved context**.
            3️⃣ **Do NOT Talk about the countries in your response**.
            4️⃣ If **no relevant information is found**, ask for **clarification instead of making up answers**.

            ---
            🔹 **Chat History (Last 5 Messages):** 
            {history}

            🔹 **User Input:** {input}
            🔹 **Retrieved Context (Do not include unrelated details):** {context}

            ❗ **If the context is empty or unclear, ask for clarification instead of guessing.**
            ❗ **Answer STRICTLY using the retrieved context from the database.**
            ❗ **If no relevant context is retrieved, say: "I do not have information on this topic." DO NOT suggest related topics from the database. DO NOT redirect the user to another question.**
            """
        )

        chain = (
                RunnablePassthrough.assign(
                    history=lambda x: self.get_last_5_chats(),
                    context=lambda x: self.retrieve_context(x["input"])
                )
                | prompt
                | self.llm
                | StrOutputParser()
        )

        response = chain.invoke({"input": user_input, "context": context, "history": chat_history})
        self._store_conversation(user_input, response)
        return response

    def _store_conversation(self, user_input, bot_response):
        """Stores chat history in Django database."""
        # Store user message
        ChatMessage.objects.create(
            session=self.chat_session,
            role='user',
            content=user_input
        )

        # Store bot response
        ChatMessage.objects.create(
            session=self.chat_session,
            role='bot',
            content=bot_response
        )