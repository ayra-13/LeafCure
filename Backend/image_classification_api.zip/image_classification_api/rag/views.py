import json
import uuid
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from .services.embeddings import EmbeddingsService
from .services.vector_store import VectorStoreService
from .services.chat_agent import ChatAgent
from .models import ChatSession, ChatMessage


@csrf_exempt
@require_http_methods(["POST"])
def chat_view(request):
    """API endpoint for chat with automatic session ID generation"""
    try:
        data = json.loads(request.body)
        user_input = data.get('message', '')

        # Generate a new session ID if not provided
        session_id = data.get('session_id', str(uuid.uuid4()))

        # Initialize services
        embeddings_service = EmbeddingsService()
        vector_store_service = VectorStoreService(embeddings_service)
        chat_agent = ChatAgent(vector_store_service, session_id)

        # Process message
        response = chat_agent.chat(user_input)

        return JsonResponse({
            'response': response,
            'session_id': session_id
        })
    except Exception as e:
        return JsonResponse({
            'error': str(e)
        }, status=500)


@csrf_exempt
@require_http_methods(["POST"])
def chat_session_view(request, session_id):
    """API endpoint for chat with specific session ID"""
    try:
        data = json.loads(request.body)
        user_input = data.get('message', '')

        # Initialize services
        embeddings_service = EmbeddingsService()
        vector_store_service = VectorStoreService(embeddings_service)
        chat_agent = ChatAgent(vector_store_service, session_id)

        # Process message
        response = chat_agent.chat(user_input)

        return JsonResponse({
            'response': response,
            'session_id': session_id
        })
    except Exception as e:
        return JsonResponse({
            'error': str(e)
        }, status=500)


@require_http_methods(["GET"])
def chat_sessions_view(request):
    """API endpoint to list all chat sessions"""
    try:
        sessions = ChatSession.objects.all().order_by('-created_at')
        sessions_data = []

        for session in sessions:
            # Get first message for preview
            first_message = ChatMessage.objects.filter(
                session=session,
                role='user'
            ).first()

            sessions_data.append({
                'session_id': session.session_id,
                'created_at': session.created_at.isoformat(),
                'preview': first_message.content[:50] + '...' if first_message else 'Empty chat'
            })

        return JsonResponse({
            'sessions': sessions_data
        })
    except Exception as e:
        return JsonResponse({
            'error': str(e)
        }, status=500)