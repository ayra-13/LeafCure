from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
import google.generativeai as genai
import os
import json

# Configure the Gemini API
genai.configure(api_key='AIzaSyDk2kcc2fx_TOV5dZWC5Br-RXUL6RvN-dc')

# Initialize the model
model = genai.GenerativeModel('gemini-pro')


class ChatbotAPIView(APIView):
    def post(self, request):
        user_input = request.data.get('message')
        if not user_input:
            return Response({'error': 'Message is required'}, status=status.HTTP_400_BAD_REQUEST)

        prompt = f"""
        You are a Rice Leaf Specialist. Your task is to answer user queries related to rice leaf health, diseases, treatments, and farming practices. 

        **Instructions:**
        - If the question is irrelevant to rice leaf health or farming, respond with: "Question is not about this domain."
        - If the user greets you and their query is related to rice leaf health or farming, acknowledge the greeting and then answer their query.

        **User Query:** {user_input}

        Provide your response in the following structured JSON format and do not include any other information:
        {{
          "response": "Your detailed answer here",
          "is_relevant": true/false
        }}
        """

        try:
            # Get response from Gemini
            response = model.generate_content(prompt)

            # Debugging print
            print("Raw Response:", response)

            if not response.text:
                return Response({"error": "Empty response from Gemini"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            # Parse response safely
            try:
                response_data = json.loads(response.text)
            except json.JSONDecodeError:
                return Response({"error": "Invalid JSON format from Gemini"},
                                status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            # Extract required fields
            result = {
                "response": response_data.get("response", ""),
                "is_relevant": response_data.get("is_relevant", False)
            }

            return Response(result, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
