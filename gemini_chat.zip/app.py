import streamlit as st
import google.generativeai as genai

# Configure your API key
genai.configure(api_key="AIzaSyB5W5ISbQ-utFXp0LrnmvlKoKOotqeUAJc")

# Initialize the Gemini model
model = genai.GenerativeModel("gemini-pro")

# Function to chat with Gemini
def chat_with_gemini(prompt):
    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"Error: {str(e)}"

# Streamlit UI
st.title("Chatbot")
st.write("Chat with us!")

# User input
user_input = st.text_input("You:", "")

if st.button("Send"):
    if user_input.strip() != "":
        response = chat_with_gemini(user_input)
        st.text_area("Gemini:", response, height=200)
    else:
        st.warning("Please enter a message!")
