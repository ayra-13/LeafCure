import google.generativeai as genai

# Set your API key
genai.configure(api_key="AIzaSyB5W5ISbQ-utFXp0LrnmvlKoKOotqeUAJc")

# Initialize the Gemini model
model = genai.GenerativeModel("gemini-pro")

def chat_with_gemini(prompt):
    response = model.generate_content(prompt)
    return response.text

# Example usage
user_input = input("You: ")  # Take user input
response = chat_with_gemini(user_input)  # Get Gemini response
print("Gemini:", response)  # Print response
